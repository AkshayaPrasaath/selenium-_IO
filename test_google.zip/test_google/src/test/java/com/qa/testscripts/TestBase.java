package com.qa.testscripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.qa.pages.Pages;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase
{
	WebDriver d;
	@Parameters({"Browser","Url"})
	@BeforeClass
	public void SelectBrowser(String Browser,String Url)
	{
		if(Browser.equalsIgnoreCase("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			d=new ChromeDriver();
		}
		Pages p=new Pages(d);
		d.get(Url);
		d.manage().window().maximize();
		
	}
}
