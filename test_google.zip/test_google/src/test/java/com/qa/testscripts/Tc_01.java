package com.qa.testscripts;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.Pages;

public class Tc_01 extends TestBase
{
	@SuppressWarnings("static-access")
	@Parameters({"Browser","Url"})
	@Test
	public void Do(String Browser,String Url) throws IOException, InterruptedException
	{
		try {
		File  loc= new File("C:\\Users\\ssr\\eclipse-workspace\\test_google\\src\\test\\java\\com\\qa\\testdata\\Data.txt");
		Pages q=new Pages(d);
		FileReader fr=new FileReader(loc);
//		@SuppressWarnings("resource")
		BufferedReader br=new BufferedReader(fr);
		String cont="";
		while((cont=br.readLine())!=null)
		{
		System.out.println(cont);
		q.box.sendKeys(cont+Keys.ENTER);
		Thread.sleep(2000);
		d.navigate().back();
		Thread.sleep(100);
		}
	}
	
	catch(IOException e)
	{
		System.out.println("error occured");
		e.printStackTrace();
	}
}
}